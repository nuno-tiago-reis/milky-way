
var Particle1Button : Transform;
var Particle2Button : Transform;
var Particle3Button : Transform;
var Particle4Button : Transform;
var Particle5Button : Transform;
var Particle6Button : Transform;
var Particle7Button : Transform;
var Particle8Button : Transform;
var Particle9Button : Transform;
var Particle10Button : Transform;


function Update(){	

if (Input.GetMouseButtonDown (0)) {
	var ray = Camera.main.ScreenPointToRay (Input.mousePosition);
	var hit:RaycastHit;
	if (Physics.Raycast (ray, hit, 50)) {
	
if(hit.collider.name == "Particle1Button")
		animation.Play();
}
}
}				